export { default } from './CatalogoPage'
