export { default } from './CategoriasPage'
