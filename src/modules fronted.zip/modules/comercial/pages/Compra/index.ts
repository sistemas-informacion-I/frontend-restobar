export { default } from './Compra'
