export { default } from './ProductosSucursalesPage'
