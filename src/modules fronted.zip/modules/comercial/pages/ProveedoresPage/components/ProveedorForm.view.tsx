import { useForm, Controller } from 'react-hook-form'
import { Input } from '@/shared/components/ui/Input'
import { FormSelect } from '@/shared/components/ui/forms'
import { Button } from '@/shared/components/ui/Button'
import { Truck, Hash, User, Phone, Mail, MapPin, Tag, AlertCircle } from 'lucide-react'
import { Proveedor, CreateProveedorData } from '@/modules/comercial/services/proveedores.service'

interface ProveedorFormProps {
  proveedor: Proveedor | null
  onSubmit: (data: CreateProveedorData) => Promise<void>
  onCancel: () => void
  isLoading: boolean
}

const CATEGORIA_OPTIONS = [
  { value: '', label: 'Seleccionar categoría' },
  { value: 'BEBIDAS', label: 'Bebidas' },
  { value: 'ALIMENTOS', label: 'Alimentos' },
  { value: 'INSUMOS', label: 'Insumos' },
  { value: 'LIMPIEZA', label: 'Limpieza' },
  { value: 'UTENSILIOS', label: 'Utensilios' },
  { value: 'SERVICIOS', label: 'Servicios' },
  { value: 'OTROS', label: 'Otros' },
]

export function ProveedorForm({ proveedor, onSubmit, onCancel, isLoading }: ProveedorFormProps) {
  const isEdit = !!proveedor

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<CreateProveedorData>({
    defaultValues: proveedor ? {
      empresa: proveedor.empresa,
      nit: proveedor.nit || '',
      nombreContacto: proveedor.nombreContacto,
      telefono: proveedor.telefono,
      correo: proveedor.correo || '',
      direccion: proveedor.direccion || '',
      categoriaProductos: proveedor.categoriaProductos,
      activo: proveedor.activo,
    } : {
      empresa: '',
      nit: '',
      nombreContacto: '',
      telefono: '',
      correo: '',
      direccion: '',
      categoriaProductos: undefined,
      activo: true,
    },
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">

        <div className="md:col-span-2">
          <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-wine-900/40 dark:text-wine-100/30 mb-4 flex items-center gap-2">
            Datos de la Empresa
            <div className="h-px flex-1 bg-wine-100/50 dark:bg-wine-900/20" />
          </h3>
        </div>

        <div className="md:col-span-2">
          <Input
            label="Nombre de la Empresa"
            type="text"
            placeholder="Razón social o nombre comercial"
            icon={<Truck size={18} />}
            error={errors.empresa?.message}
            {...register('empresa', { required: 'La empresa es obligatoria' })}
          />
        </div>

        <Input
          label="NIT"
          type="text"
          placeholder="Número de identificación tributaria"
          icon={<Hash size={18} />}
          {...register('nit')}
        />

        <div className="flex flex-col gap-1.5 group">
          <label className="text-[10px] font-black uppercase tracking-[0.2em] text-wine-900/40 dark:text-wine-400/40 px-1">
            Categoría de Productos
          </label>
          <Controller
            name="categoriaProductos"
            control={control}
            rules={{ required: 'La categoría es obligatoria' }}
            render={({ field }) => (
              <FormSelect
                {...field}
                options={CATEGORIA_OPTIONS}
                icon={<Tag size={18} />}
                placeholder="Seleccionar categoría"
              />
            )}
          />
          {errors.categoriaProductos && (
            <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-rose-600 px-1 animate-in slide-in-from-top-1">
              <AlertCircle size={12} className="shrink-0" />
              {errors.categoriaProductos.message}
            </span>
          )}
        </div>

        <div className="md:col-span-2">
          <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-wine-900/40 dark:text-wine-100/30 mb-4 mt-2 flex items-center gap-2">
            Datos de Contacto
            <div className="h-px flex-1 bg-wine-100/50 dark:bg-wine-900/20" />
          </h3>
        </div>

        <Input
          label="Nombre del Contacto"
          type="text"
          placeholder="Persona encargada"
          icon={<User size={18} />}
          error={errors.nombreContacto?.message}
          {...register('nombreContacto', { required: 'El nombre del contacto es obligatorio' })}
        />

        <Input
          label="Teléfono"
          type="text"
          placeholder="Número de contacto"
          icon={<Phone size={18} />}
          error={errors.telefono?.message}
          {...register('telefono', { required: 'El teléfono es obligatorio' })}
        />

        <Input
          label="Correo Electrónico"
          type="email"
          placeholder="correo@empresa.com"
          icon={<Mail size={18} />}
          {...register('correo')}
        />

        <Input
          label="Dirección"
          type="text"
          placeholder="Dirección física de la empresa"
          icon={<MapPin size={18} />}
          {...register('direccion')}
        />

      </div>

      <div className="mt-4 flex flex-col-reverse justify-end gap-3 border-t border-wine-100/30 pt-6 dark:border-wine-900/10 sm:flex-row">
        <Button
          type="button"
          variant="ghost"
          onClick={onCancel}
          className="bg-wine-50/50 dark:bg-wine-950/30"
        >
          Cancelar
        </Button>
        <Button
          type="submit"
          isLoading={isLoading}
          className="shadow-lg shadow-wine-900/20 min-w-[200px]"
        >
          {isEdit ? 'Guardar Cambios' : 'Registrar Proveedor'}
        </Button>
      </div>
    </form>
  )
}
