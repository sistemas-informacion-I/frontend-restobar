export { default } from './ProveedoresPage'
