export { default } from './RecetasPage'
